/* gtk_support.h
 * Definitions for GTK Support
 *
 * Yersinia
 * By David Barroso <tomac@yersinia.net> and Alfredo Andres <aandreswork@hotmail.com>
 * Copyright 2005-2017 Alfredo Andres and David Barroso
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef __GTK_SUPPORT_H__
#define __GTK_SUPPORT_H__

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

/*
 * Standard gettext macros.
 */
#ifdef ENABLE_NLS
#  include <libintl.h>
#  undef _
#  define _(String) dgettext (PACKAGE, String)
#  define Q_(String) g_strip_context ((String), gettext (String))
#  ifdef gettext_noop
#    define N_(String) gettext_noop (String)
#  else
#    define N_(String) (String)
#  endif
#else
#  define textdomain(String) (String)
#  define gettext(String) (String)
#  define dgettext(Domain,Message) (Message)
#  define dcgettext(Domain,Message,Type) (Message)
#  define bindtextdomain(Domain,Directory) (Domain)
#  define _(String) (String)
#  define Q_(String) g_strip_context ((String), (String))
#  define N_(String) (String)
#endif


/*
 * Public Functions.
 */

/*
 * This function returns a widget in a component created by Glade.
 * Call it with the toplevel widget in the component (i.e. a window/dialog),
 * or alternatively any widget in the component, and the name of the widget
 * you want returned.
 */
GtkWidget*  lookup_widget              (GtkWidget       *widget,
                                        const gchar     *widget_name);


/* Use this function to set the directory containing installed pixmaps. */
void        add_pixmap_directory       (const gchar     *directory);


/*
 * Private Functions.
 */

/* This is used to create the pixmaps used in the interface. */
GtkWidget*  create_pixmap              (GtkWidget       *widget,
                                        const gchar     *filename);

/* This is used to create the pixbufs used in the interface. */
GdkPixbuf*  create_pixbuf              (const gchar     *filename);

/* This is used to set ATK action descriptions. */
void        glade_set_atk_action_description (AtkAction       *action,
                                              const gchar     *action_name,
                                              const gchar     *description);


struct gtk_s_helper {
    struct term_node *node;
    u_int8_t mode;
    u_int8_t row;
    u_int8_t extra;
    GtkWidget *notebook;
    GtkTooltips *tooltips;
    GtkTreeSelection *select;
    GtkWidget *statusbar;
    u_int8_t edit_mode;
    struct _attack_definition *attack_def;
    struct attack_param *attack_param;
};


typedef struct _GTK_ATTACK_CONTEXT_ {
    GtkWidget *dialog ;      /* Attacks list main dialog */
    GtkWidget *h_box ;       /* Horizontal box where the current attack lies, useful for disabling graphically... */
    struct term_node *node ;
    u_int8_t protocol ;
    u_int8_t attack ;
} GTK_ATTACK_CONTEXT ;


typedef struct _GTK_DIALOG_ATTACK_CONTEXT_ {
    GtkWidget *dialog ;      /* Attacks list main dialog */
    struct term_node *node ;
    GTK_ATTACK_CONTEXT *enabled_attacks_list ;
} GTK_DIALOG_ATTACK_CONTEXT ;


typedef struct _GTK_ATTACK_PARAMS_CONTEXT_ {
    struct gtk_s_helper *helper ;
    GtkWidget *dialog ;           /* Attacks parameters dialog */
    GtkWidget **vh_entry ;        /* Widget list relating to attack parameters */
    u_int8_t nparams ;            /* parameters count */
    struct attack_param *params_list ;
    int8_t attack_status ;
} GTK_ATTACK_PARAMS_CONTEXT ;


#endif
