telegram.Animation
==================

.. autoclass:: telegram.Animation
    :members:
    :show-inheritance:
