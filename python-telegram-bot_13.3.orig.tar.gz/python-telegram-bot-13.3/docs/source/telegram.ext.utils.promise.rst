telegram.ext.utils.promise.Promise
==================================

.. autoclass:: telegram.ext.utils.promise.Promise
    :members:
    :show-inheritance:
