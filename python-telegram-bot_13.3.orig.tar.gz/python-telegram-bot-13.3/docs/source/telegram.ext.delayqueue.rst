telegram.ext.DelayQueue
=======================

.. autoclass:: telegram.ext.DelayQueue
    :members:
    :show-inheritance:
    :special-members:
