telegram.utils.request.Request
==============================

.. autoclass:: telegram.utils.request.Request
    :members:
    :show-inheritance:
