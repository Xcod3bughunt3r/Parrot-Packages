telegram.ext.CommandHandler
===========================

.. autoclass:: telegram.ext.CommandHandler
    :members:
    :show-inheritance:
