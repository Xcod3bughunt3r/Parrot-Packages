telegram.constants Module
=========================

.. automodule:: telegram.constants
    :members:
    :show-inheritance:
