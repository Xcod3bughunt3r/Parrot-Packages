telegram.Invoice
================

.. autoclass:: telegram.Invoice
    :members:
    :show-inheritance:
