telegram.PassportElementErrorDataField
======================================

.. autoclass:: telegram.PassportElementErrorDataField
    :members:
    :show-inheritance:
