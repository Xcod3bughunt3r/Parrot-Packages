telegram.PreCheckoutQuery
=========================

.. autoclass:: telegram.PreCheckoutQuery
    :members:
    :show-inheritance:
