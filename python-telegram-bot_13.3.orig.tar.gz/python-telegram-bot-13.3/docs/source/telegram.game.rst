telegram.Game
=============

.. autoclass:: telegram.Game
    :members:
    :show-inheritance:
