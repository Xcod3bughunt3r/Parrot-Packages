package com.github.markusbernhardt.proxy.util;

/*****************************************************************************
 * Indicates an exception in the proxy framework.
 *
 * @author Markus Bernhardt, Copyright 2016
 * @author Bernd Rosstauscher, Copyright 2009
 ****************************************************************************/

public class ProxyException extends Exception {

	private static final long serialVersionUID = 1L;

	/*************************************************************************
	 * Constructor
	 ************************************************************************/

	public ProxyException() {
		super();
	}

	/*************************************************************************
	 * Constructor
	 * 
	 * @param message
	 *            the error message
	 * @param cause
	 *            the causing exception for chaining exceptions.
	 ************************************************************************/

	public ProxyException(String message, Throwable cause) {
		super(message, cause);
	}

	/*************************************************************************
	 * Constructor
	 * 
	 * @param message
	 *            the error message
	 ************************************************************************/

	public ProxyException(String message) {
		super(message);
	}

	/*************************************************************************
	 * Constructor
	 * 
	 * @param cause
	 *            the causing exception for chaining exceptions.
	 ************************************************************************/

	public ProxyException(Throwable cause) {
		super(cause);
	}

}
