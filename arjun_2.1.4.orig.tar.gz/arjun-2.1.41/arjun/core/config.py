var = {} # all the cli arguments are added to this variable to be accessed globally
